import { z } from "zod";
import { phoneSchema, otpCodeSchema } from "../../utils/validators.js";

export const agencyIdParam = z.object({ agencyId: z.coerce.number().int().positive() });
export const agencyBookingParams = agencyIdParam.extend({ bookingId: z.coerce.number().int().positive() });
export const agencyMemberParams = agencyIdParam.extend({ memberId: z.coerce.number().int().positive() });
export const memberIdParam = z.object({ memberId: z.coerce.number().int().positive() });
export const assignmentIdParam = z.object({ assignmentId: z.coerce.number().int().positive() });

export const registerAgencySchema = z.object({
    name: z.string().trim().min(2).max(120),
    phone: phoneSchema,
    email: z.string().trim().toLowerCase().email().max(254).optional(),
    legalName: z.string().trim().max(200).optional(),
    description: z.string().trim().max(2000).optional(),
    address: z.string().trim().max(500).optional(),
    city: z.string().trim().min(1).max(100),
    state: z.string().trim().min(1).max(100),
    pincode: z.string().trim().regex(/^\d{6}$/, "Pincode must be 6 digits"),
    latitude: z.number().min(-90).max(90),
    longitude: z.number().min(-180).max(180),
    serviceRadiusKm: z.number().int().min(1).max(100).optional(),
});

export const agencyAvailabilitySchema = z.object({
    status: z.enum(["ONLINE", "OFFLINE"]),
    latitude: z.number().min(-90).max(90).optional(),
    longitude: z.number().min(-180).max(180).optional(),
});

export const agencyServiceSchema = z.object({
    serviceId: z.number().int().positive(),
    customPrice: z.number().nonnegative().max(10_000_000).nullable().optional(),
    isActive: z.boolean().optional(),
});

export const addStaffSchema = z.object({
    phone: phoneSchema,
    displayName: z.string().trim().max(100).optional(),
    experienceYears: z.number().int().min(0).max(60).optional(),
});

export const memberStatusSchema = z.object({ status: z.enum(["ACTIVE", "SUSPENDED", "REMOVED"]) });
export const staffServicesSchema = z.object({ serviceIds: z.array(z.number().int().positive()).max(100) });
export const assignStaffSchema = z.object({ staffMemberId: z.number().int().positive(), notes: z.string().trim().max(500).optional() });
export const respondSchema = z.object({ reason: z.string().trim().max(500).optional() });
export const completeSchema = z.object({ otp: otpCodeSchema });
