
import { AppError } from "../../../errors/AppError.js";
import { generateTokens } from "../../../helper/generateTokens.js";
import { verifyToken, parseUserId } from "../../../helper/verifyToken.js";
import { prisma } from "../../../lib/prisma.js";
import { sendOTP, verifyOTP } from "../../../services/otp.service.js";
import { env } from "../../../config/env.js";

interface SendProviderOTPInput {
    phone: string;
}

interface VerifyProviderOTPInput {
    phone: string;
    code: string;
}

const providerUserSelect = {
    id: true,
    phone: true,
    name: true,
    email: true,
    isPhoneVerified: true,
    accountStatus: true,
    userRoles: {
        select: {
            role: true,
        },
    },
    providerProfile: {
        select: {
            id: true,
            displayName: true,
            bio: true,
            experienceYears: true,
            status: true,
            verificationStatus: true,
            availabilityStatus: true,
            isAvailable: true,
            createdAt: true,
        },
    },
} as const;

// 1. Send Provider OTP
const sendProviderOTP = async (payload: SendProviderOTPInput) => {
    const phone = payload.phone?.trim();

    if (!phone) {
        throw new AppError(400, "Phone number is required");
    }

    const existingUser = await prisma.user.findUnique({
        where: { phone },
        select: {
            id: true,
            accountStatus: true,
            providerProfile: {
                select: { id: true },
            },
        },
    });

    if (existingUser?.accountStatus === "BLOCKED") {
        throw new AppError(403, "Your account is blocked");
    }

    if (existingUser?.accountStatus === "DELETED") {
        throw new AppError(404, "User account not found");
    }

    const result = await sendOTP(
        phone,
        existingUser?.providerProfile ? "LOGIN" : "REGISTRATION"
    );

    return {
        phone,
        status: result.status,
        message: "Provider OTP sent successfully",
    };
};

// 2. Verify OTP + Create Provider Account
const verifyProviderOTP = async (
    payload: VerifyProviderOTPInput
) => {
    const phone = payload.phone?.trim();
    const code = payload.code?.trim();

    if (!phone || !code) {
        throw new AppError(400, "Phone number and OTP are required");
    }

    const isVerified = await verifyOTP(phone, code);

    if (!isVerified) {
        throw new AppError(400, "Invalid or expired OTP");
    }

    // Determine "new provider" before creating anything (PRV-02: replaces the 5-second heuristic)
    const existingProfile = await prisma.providerProfile.findFirst({
        where: { user: { phone } },
        select: { id: true },
    });

    const user = await prisma.$transaction(async (tx) => {
        let currentUser = await tx.user.findUnique({
            where: { phone },
            select: {
                id: true,
                accountStatus: true,
                tokenVersion: true,
            },
        });

        if (currentUser?.accountStatus === "BLOCKED") {
            throw new AppError(403, "Your account is blocked");
        }

        if (currentUser?.accountStatus === "DELETED") {
            throw new AppError(404, "User account not found");
        }

        // Create or update User
        if (currentUser) {
            currentUser = await tx.user.update({
                where: { id: currentUser.id },
                data: { isPhoneVerified: true },
                select: {
                    id: true,
                    accountStatus: true,
                    tokenVersion: true,
                },
            });
        } else {
            currentUser = await tx.user.create({
                data: {
                    phone,
                    isPhoneVerified: true,
                },
                select: {
                    id: true,
                    accountStatus: true,
                    tokenVersion: true,
                },
            });
        }

        // Assign PROVIDER role
        await tx.userRole.upsert({
            where: {
                userId_role: {
                    userId: currentUser.id,
                    role: "PROVIDER",
                },
            },
            update: {},
            create: {
                userId: currentUser.id,
                role: "PROVIDER",
            },
        });

        // Create Provider Profile if it doesn't exist
        const providerProfile = await tx.providerProfile.upsert({
            where: {
                userId: currentUser.id,
            },
            update: {},
            create: {
                userId: currentUser.id,
                status: "PENDING",
                verificationStatus: "NOT_SUBMITTED",
                availabilityStatus: "OFFLINE",
                isAvailable: false,
            },
            select: {
                id: true,
            },
        });

        // Create Provider Wallet if it doesn't exist
        await tx.providerWallet.upsert({
            where: {
                providerId: providerProfile.id,
            },
            update: {},
            create: {
                providerId: providerProfile.id,
                balance: 0,
                pendingBalance: 0,
                totalEarnings: 0,
                totalWithdrawn: 0,
            },
        });

        return currentUser;
    });


    if (user.accountStatus !== "ACTIVE") {
        throw new AppError(403, "Your account is not active");
    }

    const tokens = generateTokens(user.id, user.tokenVersion);

    const provider = await prisma.user.findUniqueOrThrow({
        where: { id: user.id },
        select: providerUserSelect,
    });

    return {
        message: "Provider authentication successful",
        isNewProvider: !existingProfile,
        provider,
        ...tokens,
    };
};

// 3. Provider Refresh Token
const refreshProviderToken = async (refreshToken: string) => {
    const decoded = verifyToken(
        refreshToken,
        env.JWT_REFRESH_SECRET,
        "refresh"
    );

    const userId = parseUserId(decoded.sub);

    const user = await prisma.user.findUnique({
        where: { id: userId },
        select: {
            id: true,
            accountStatus: true,
            isPhoneVerified: true,
            tokenVersion: true,
            userRoles: {
                where: { role: "PROVIDER" },
                select: { id: true },
            },
            providerProfile: {
                select: { id: true },
            },
        },
    });

    if (
        !user ||
        user.accountStatus !== "ACTIVE" ||
        !user.isPhoneVerified
    ) {
        throw new AppError(401, "Provider account is inactive");
    }

    if (!user.userRoles.length || !user.providerProfile) {
        throw new AppError(403, "Provider account not found");
    }

    if (user.tokenVersion !== decoded.ver) {
        throw new AppError(401, "Session has been revoked. Please log in again.");
    }

    return generateTokens(user.id, user.tokenVersion);
};

// 4. Get Provider Profile
const getMyProviderProfile = async (userId: number) => {
    const provider = await prisma.user.findUnique({
        where: { id: userId },
        select: providerUserSelect,
    });

    if (!provider || !provider.providerProfile) {
        throw new AppError(404, "Provider profile not found");
    }

    const hasProviderRole = provider.userRoles.some(
        (item) => item.role === "PROVIDER"
    );

    if (!hasProviderRole) {
        throw new AppError(403, "Provider access required");
    }

    return provider;
};

export const ProviderAuthService = {
    sendProviderOTP,
    verifyProviderOTP,
    refreshProviderToken,
    getMyProviderProfile,
};
