
import type { Request, Response } from "express";
import { AppError } from "../../../errors/AppError.js";
import catchAsync from "../../../utils/catchAsync.js";
import sendResponse from "../../../utils/sendResponse.js";
import { ProviderAuthService } from "./provider-auth.service.js";

const sendOTP = catchAsync(async (req: Request, res: Response) => {
    const result = await ProviderAuthService.sendProviderOTP({
        phone: req.body.phone,
    });

    return sendResponse(res, {
        success: true,
        statusCode: 200,
        message: result.message,
        data: {
            phone: result.phone,
            status: result.status,
        },
    });
});

const verifyOTP = catchAsync(async (req: Request, res: Response) => {
    const result = await ProviderAuthService.verifyProviderOTP({
        phone: req.body.phone,
        code: req.body.code,
    });

    return sendResponse(res, {
        success: true,
        statusCode: 200,
        message: result.message,
        data: {
            isNewProvider: result.isNewProvider,
            provider: result.provider,
            tokens: {
                accessToken: result.accessToken,
                refreshToken: result.refreshToken,
            },
        },
    });
});

const refreshToken = catchAsync(async (req: Request, res: Response) => {
    const { refreshToken } = req.body;

    if (!refreshToken) {
        throw new AppError(400, "Refresh token is required");
    }

    const tokens = await ProviderAuthService.refreshProviderToken(
        refreshToken
    );

    return sendResponse(res, {
        success: true,
        statusCode: 200,
        message: "Provider token refreshed successfully",
        data: tokens,
    });
});

const getMe = catchAsync(async (req: Request, res: Response) => {
    const userId = Number(req.user?.id);

    if (!userId) {
        throw new AppError(401, "Unauthorized access");
    }

    const provider = await ProviderAuthService.getMyProviderProfile(userId);

    return sendResponse(res, {
        success: true,
        statusCode: 200,
        message: "Provider profile retrieved successfully",
        data: provider,
    });
});

export const ProviderAuthController = {
    sendOTP,
    verifyOTP,
    refreshToken,
    getMe,
};
