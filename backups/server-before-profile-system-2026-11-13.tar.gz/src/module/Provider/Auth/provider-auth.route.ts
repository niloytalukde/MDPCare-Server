import { Router } from "express";
import { ProviderAuthController } from "./provider-auth.controller.js";
import { AuthController } from "../../Auth/auth.controller.js";
import auth from "../../../middleware/auth.js";
import providerAuth from "../../../middleware/providerAuth.js";
import validate from "../../../middleware/validate.js";
import { otpSendLimiter, otpVerifyLimiter, refreshLimiter } from "../../../middleware/rateLimiter.js";
import { sendOtpSchema, verifyOtpSchema, refreshTokenSchema } from "./provider-auth.validation.js";

const router = Router();

// Public routes
router.post("/send-otp", otpSendLimiter, validate({ body: sendOtpSchema }), ProviderAuthController.sendOTP);
router.post("/verify-otp", otpVerifyLimiter, validate({ body: verifyOtpSchema }), ProviderAuthController.verifyOTP);
router.post("/refresh-token", refreshLimiter, validate({ body: refreshTokenSchema }), ProviderAuthController.refreshToken);

// Protected Provider routes
router.get("/me", auth, providerAuth, ProviderAuthController.getMe);
router.post("/logout", auth, AuthController.logout);

export const ProviderAuthRoutes = router;
export default router;
