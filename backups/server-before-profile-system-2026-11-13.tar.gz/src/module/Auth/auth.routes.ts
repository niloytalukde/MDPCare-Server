import { Router } from "express";
import { AuthController } from "./auth.controller.js";
import auth from "../../middleware/auth.js";
import validate from "../../middleware/validate.js";
import { otpSendLimiter, otpVerifyLimiter, refreshLimiter } from "../../middleware/rateLimiter.js";
import { sendOtpSchema, verifyOtpSchema, refreshTokenSchema, updateProfileSchema } from "./auth.validation.js";

const router = Router();

// Public authentication routes
router.post("/send-otp", otpSendLimiter, validate({ body: sendOtpSchema }), AuthController.sendOTP);
router.post("/verify-otp", otpVerifyLimiter, validate({ body: verifyOtpSchema }), AuthController.verifyOTP);
router.post("/refresh-token", refreshLimiter, validate({ body: refreshTokenSchema }), AuthController.refreshAccessToken);

// Protected routes (requires Bearer JWT access token)
router.get("/me", auth, AuthController.getMyProfile);
router.patch("/profile", auth, validate({ body: updateProfileSchema }), AuthController.updateProfile);
router.post("/logout", auth, AuthController.logout);

export const AuthRoutes = router;
export default router;
