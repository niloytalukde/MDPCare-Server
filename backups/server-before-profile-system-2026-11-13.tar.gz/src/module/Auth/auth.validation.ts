import { z } from "zod";
import { phoneSchema, otpCodeSchema } from "../../utils/validators.js";

export const sendOtpSchema = z.object({ phone: phoneSchema });

export const verifyOtpSchema = z.object({ phone: phoneSchema, code: otpCodeSchema });

export const refreshTokenSchema = z.object({ refreshToken: z.string().min(1).max(2048) });

export const updateProfileSchema = z.object({
    name: z.string().trim().min(1).max(100),
    email: z.string().trim().toLowerCase().email().max(254).nullable().optional(),
    gender: z.enum(["MALE", "FEMALE", "OTHER", "PREFER_NOT_TO_SAY"]).nullable().optional(),
});
